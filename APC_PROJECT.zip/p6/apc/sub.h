#ifndef SUB_H
#define SUB_H

#include "apc.h"

/* Handles subtraction of two signed operands */
void sub_op(char *op1, char *op2);

/* Performs subtraction of two numbers */
void subtractOperation(dlist *head1,
                       dlist *tail1,
                       dlist *head2,
                       dlist *tail2,
                       int negative);

/* Compares two numbers stored in doubly linked lists */
int compare_lists(dlist *head1, dlist *head2);

#endif
