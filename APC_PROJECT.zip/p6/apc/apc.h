#ifndef APC_H
#define APC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct node
{
    struct node *prev;
    int data;
    struct node *next;
} dlist;

void print_list(dlist *head, dlist *tail);

void insert_first(dlist **head, dlist **tail, int data);

void insert_last(dlist **head, dlist **tail, int data);

int is_zero(dlist *head);

void free_list(dlist **head);

void get_sign(char **str, int *sign);

#endif