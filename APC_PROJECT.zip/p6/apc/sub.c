#include "sub.h"
#include "add.h"

/* Driver function for Subtraction

   Responsibilities:
   -----------------
   1. Extract signs from operands.
   2. Convert operands into doubly linked lists.
   3. Print operands.
   4. Decide whether subtraction or addition is required
      based on operand signs.
   5. Free allocated memory.
*/
void sub_op(char *op1, char *op2)
{
    int sign1, sign2;

    //Remove '+' or '-' and store the sign
    get_sign(&op1, &sign1);
    get_sign(&op2, &sign2);

    dlist *head1 = NULL;
    dlist *tail1 = NULL;

    dlist *head2 = NULL;
    dlist *tail2 = NULL;

    //Convert Operand-1 into linked list
    for(int i = 0; op1[i] != '\0'; i++)
    {
        insert_last(&head1, &tail1, op1[i] - '0');
    }

    //Convert Operand-2 into linked list
    for(int i = 0; op2[i] != '\0'; i++)
    {
        insert_last(&head2, &tail2, op2[i] - '0');
    }

    printf("Operand1 : ");
    if(sign1 == -1)
        printf("-");
    print_list(head1, tail1);

    printf("\nOperand2 : ");
    if(sign2 == -1)
        printf("-");
    print_list(head2, tail2);
    printf("\n");

    /* Sign combinations

       +A - +B = A-B
       -A - -B = B-A
       +A - -B = A+B
       -A - +B = -(A+B)
    */

    if(sign1 == 1 && sign2 == 1)
    {
        subtractOperation(head1, tail1,
                          head2, tail2,
                          0);
    }
    else if(sign1 == -1 && sign2 == -1)
    {
        subtractOperation(head2, tail2,
                          head1, tail1,
                          0);
    }
    else if(sign1 == 1 && sign2 == -1)
    {
        addOperation(head1, tail1,
                     head2, tail2,
                     0);
    }
    else
    {
        addOperation(head1, tail1,
                     head2, tail2,
                     1);
    }

    //Free operand lists
    free_list(&head1);
    free_list(&head2);
}

/* Perform subtraction.

   Algorithm:
   ----------
   1. Compare both numbers.
   2. If Operand-2 is larger, swap operands.
   3. Perform subtraction from Least Significant Digit.
   4. Handle borrow whenever required.
   5. Remove leading zeros.
*/
void subtractOperation(dlist *head1,dlist *tail1,
                       dlist *head2,dlist *tail2,
                       int negative)
{
    //Compare both operands
    int cmp = compare_lists(head1, head2);

    //Swap operands if Operand-2 is greater
    if(cmp < 0)
    {
        dlist *temp;

        temp = head1;
        head1 = head2;
        head2 = temp;

        temp = tail1;
        tail1 = tail2;
        tail2 = temp;

        //Result becomes negative after swapping
        negative = !negative;
    }

    dlist *headR = NULL;
    dlist *tailR = NULL;

    int borrow = 0;

    //Traverse from Least Significant Digit
    while(tail1 != NULL || tail2 != NULL)
    {
        int n1 = 0;
        int n2 = 0;

        if(tail1 != NULL)
        {
            n1 = tail1->data;
            tail1 = tail1->prev;
        }

        if(tail2 != NULL)
        {
            n2 = tail2->data;
            tail2 = tail2->prev;
        }

        //Apply previous borrow
        n1 = n1 - borrow;

        //Borrow from next digit if required
        if(n1 < n2)
        {
            n1 = n1 + 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        //Store current result digit
        insert_first(&headR, &tailR, n1 - n2);
    }

    //Remove leading zeros from result
    while(headR != NULL &&
          headR->data == 0 &&
          headR->next != NULL)
    {
        dlist *temp = headR;
        headR = headR->next;
        headR->prev = NULL;
        free(temp);
    }

    printf("\nDifference : ");

    //Avoid printing "-0"
    if(compare_lists(headR, headR) == 0 &&
       headR->data == 0)
    {
        negative = 0;
    }

    if(negative)
    {
        printf("-");
    }

    print_list(headR, tailR);
    printf("\n");

    //Free result list
    free_list(&headR);
}

/* Compare two linked-list numbers.

   Returns:
        1  -> Number1 > Number2
        0  -> Number1 == Number2
       -1  -> Number1 < Number2
*/
int compare_lists(dlist *head1, dlist *head2)
{
    int len1 = 0, len2 = 0;
    dlist *temp;

    //Find length of first operand
    for(temp = head1; temp != NULL; temp = temp->next)
        len1++;

    //Find length of second operand
    for(temp = head2; temp != NULL; temp = temp->next)
        len2++;

    //Longer number is greater
    if(len1 > len2)
        return 1;

    if(len1 < len2)
        return -1;

    //If lengths are equal, compare digit by digit
    while(head1 != NULL && head2 != NULL)
    {
        if(head1->data > head2->data)
            return 1;

        if(head1->data < head2->data)
            return -1;

        head1 = head1->next;
        head2 = head2->next;
    }

    //Numbers are equal
    return 0;
}