#ifndef DIV_H
#define DIV_H

#include "apc.h"

/* Compares two numbers stored in doubly linked lists */
int compare(dlist *head1, dlist *head2);

/* Moves one digit from dividend to the current number */
void append_digit(dlist **head1,
                  dlist **tail1,
                  dlist **headCurrent,
                  dlist **tailCurrent);

/* Removes unnecessary leading zeros */
void remove_leading_zeros(dlist **head, dlist **tail);

/* Subtracts the second number from the first number */
void subtract_lists(dlist *tail1,
                    dlist *tail2,
                    dlist **headResult,
                    dlist **tailResult);

/* Performs long division */
void divOperation(dlist **headDividend,
                  dlist **tailDividend,
                  dlist *headDivisor,
                  dlist *tailDivisor,
                  dlist **headQuotient,
                  dlist **tailQuotient,
                  int negative);

/* Handles division of two signed operands */
void div_op(char *op1, char *op2);

#endif