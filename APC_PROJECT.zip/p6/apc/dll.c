/*
------------------------------------------------------------
File Name : dll.c
Description :
Contains helper functions used throughout the Arbitrary
Precision Calculator project.

Functions implemented:
1. Insert node at the end of DLL.
2. Insert node at the beginning of DLL.
3. Print DLL.
4. Free DLL memory.
5. Check whether a number is zero.
6. Extract sign (+/-) from operand.
------------------------------------------------------------
*/

#include "apc.h"

/* Insert a new digit at the end of the doubly linked list.

   Example:
       1 <-> 2 <-> 3
                   |
                insert 4

       Result:
       1 <-> 2 <-> 3 <-> 4
*/
void insert_last(dlist **head, dlist **tail, int data)
{
    dlist *new = malloc(sizeof(dlist));

    if (new == NULL)
    {
        return;
    }

    new->prev = *tail;
    new->data = data;
    new->next = NULL;

    //First node in the list
    if (*head == NULL)
    {
        *head = new;
        *tail = new;
    }
    else
    {
        //Attach node after current tail
        (*tail)->next = new;
        *tail = new;
    }
}

/* Insert a new digit at the beginning of the doubly linked list.

   Example:
       2 <-> 3 <-> 4
       insert 1

       Result:
       1 <-> 2 <-> 3 <-> 4
*/
void insert_first(dlist **head, dlist **tail, int data)
{
    dlist *new = malloc(sizeof(dlist));

    if (new == NULL)
    {
        return;
    }

    new->prev = NULL;
    new->data = data;
    new->next = *head;

    //First node in the list
    if (*head == NULL)
    {
        *head = new;
        *tail = new;
    }
    else
    {
        //Attach node before current head
        (*head)->prev = new;
        *head = new;
    }
}

/* Print all digits stored in the doubly linked list.

   Example:
       1 <-> 2 <-> 3
       Output : 123
*/
void print_list(dlist *head, dlist *tail)
{
    if (head == NULL)
    {
        printf("List is Empty\n");
        return;
    }

    //Traverse from head to tail and print every digit
    while (head != NULL)
    {
        printf("%d", head->data);
        head = head->next;
    }
}

/* Free every node of the doubly linked list to avoid memory leaks. */
void free_list(dlist **head)
{
    dlist *temp;

    while (*head)
    {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }

    *head = NULL;
}

/* Check whether the entire number stored in the linked list is zero.

   Returns:
       1 -> Number is zero
       0 -> Number is non-zero

   Example:
       0000 -> 1
       0012 -> 0
*/
int is_zero(dlist *head)
{
    while(head != NULL)
    {
        if(head->data != 0)
        {
            return 0;
        }

        head = head->next;
    }

    return 1;
}

/* Extract the sign from the operand.

   If the operand begins with '+' or '-',
   move the pointer to the first digit and
   return the corresponding sign.

   Examples:
       "+123" -> sign = +1, operand = "123"
       "-456" -> sign = -1, operand = "456"
       "789"  -> sign = +1, operand = "789"
*/
void get_sign(char **op, int *sign)
{
    //Assume positive by default
    *sign = 1;

    if((*op)[0] == '-')
    {
        *sign = -1;
        (*op)++;        //Skip '-'
    }
    else if((*op)[0] == '+')
    {
        (*op)++;        //Skip '+'
    }
}