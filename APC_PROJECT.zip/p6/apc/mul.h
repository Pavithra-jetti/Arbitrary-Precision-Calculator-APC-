#ifndef MUL_H
#define MUL_H

#include "apc.h"

/* Converts a numeric string into a doubly linked list */
dlist *build_list_from_digits(const char *str, dlist **tail);

/* Removes unnecessary leading zeros */
void strip_leading_zeros(dlist **head, dlist **tail);

/* Performs multiplication of two numbers */
void mulOperation(dlist *head1,
                  dlist *tail1,
                  dlist *head2,
                  dlist *tail2,
                  dlist **headResult,
                  dlist **tailResult);

/* Handles multiplication of two signed operands */
void mul_op(const char *op1, const char *op2);

#endif
