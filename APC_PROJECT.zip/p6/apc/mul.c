#include "mul.h"

/* Convert a numeric string into a doubly linked list.

   Example:
       "1234" --> 1 <-> 2 <-> 3 <-> 4
*/

dlist *build_list_from_digits(const char *str, dlist **tail)
{
    dlist *head = NULL;

    *tail = NULL;

    //Insert each digit into the linked list
    for(int i = 0; str[i] != '\0'; i++)
    {
        insert_last(&head, tail, str[i] - '0');
    }

    return head;
}

/* Remove unnecessary leading zeros.

   Example:
       000456 -> 456
       0000   -> 0
*/

void strip_leading_zeros(dlist **head, dlist **tail)
{
    while(*head != NULL &&
          (*head)->data == 0 &&
          (*head)->next != NULL)
    {
        dlist *temp = *head;

        *head = (*head)->next;
        (*head)->prev = NULL;

        free(temp);
    }

    //Update tail pointer
    if(*head != NULL)
    {
        dlist *temp = *head;

        while(temp->next != NULL)
        {
            temp = temp->next;
        }

        *tail = temp;
    }
}

/* Perform multiplication.

   Algorithm:
   ----------
   Uses the same approach as manual multiplication.

   1. Multiply each digit of Operand-2 with every digit of Operand-1.
   2. Store partial sums in an integer array.
   3. Handle carry during multiplication.
   4. Convert the final array into a linked list.
*/

void mulOperation(dlist *headOP1,
                  dlist *tailOP1,
                  dlist *headOP2,
                  dlist *tailOP2,
                  dlist **headR,
                  dlist **tailR)
{
    int len1 = 0, len2 = 0;
    dlist *temp;

    //Calculate length of Operand-1
    for (temp = headOP1; temp != NULL; temp = temp->next)
    {
        len1++;
    }

    //Calculate length of Operand-2
    for (temp = headOP2; temp != NULL; temp = temp->next)
    {
        len2++;
    }

    //Maximum possible digits in multiplication
    int resultLen = len1 + len2;

    //Temporary array to store multiplication result
    int *result = calloc(resultLen, sizeof(int));

    *headR = NULL;
    *tailR = NULL;

    if (result == NULL)
    {
        printf("\n[ERROR] Memory allocation failed.\n");
        return;
    }

    int i2 = len2 - 1;

    //Traverse Operand-2 from Least Significant Digit
    for (dlist *ptr2 = tailOP2;
         ptr2 != NULL;
         ptr2 = ptr2->prev, i2--)
    {
        int i1 = len1 - 1;
        int carry = 0;

        //Multiply current digit with every digit of Operand-1
        for (dlist *ptr1 = tailOP1;
             ptr1 != NULL;
             ptr1 = ptr1->prev, i1--)
        {
            //Position where product should be stored
            int pos = i1 + i2 + 1;

            int product = (ptr1->data * ptr2->data)
                          + result[pos]
                          + carry;

            result[pos] = product % 10;
            carry = product / 10;
        }

        //Store remaining carry
        result[i2] += carry;
    }

    //Convert array result into linked list
    for (int i = 0; i < resultLen; i++)
    {
        insert_last(headR, tailR, result[i]);
    }

    free(result);
}

/* Driver function for Multiplication

   Responsibilities:
   -----------------
   1. Extract operand signs.
   2. Build linked lists.
   3. Perform multiplication.
   4. Print the result.
   5. Free allocated memory.
*/

void mul_op(const char *op1, const char *op2)
{
    int sign1 = 0;
    int sign2 = 0;

    //Check sign of Operand-1
    if (op1[0] == '-')
    {
        sign1 = 1;
        op1++;
    }
    else if(op1[0] == '+')
    {
        op1++;
    }

    //Check sign of Operand-2
    if (op2[0] == '-')
    {
        sign2 = 1;
        op2++;
    }
    else if(op2[0] == '+')
    {
        op2++;
    }

    //Result is negative only if signs differ
    int resultNegative = (sign1 != sign2);

    dlist *tailOP1 = NULL;
    dlist *tailOP2 = NULL;

    //Convert operands into linked lists
    dlist *headOP1 = build_list_from_digits(op1, &tailOP1);
    dlist *headOP2 = build_list_from_digits(op2, &tailOP2);

    printf("The operand1 is : %s%s\n",
           sign1 ? "-" : "", op1);

    printf("The operand2 is : %s%s\n",
           sign2 ? "-" : "", op2);

    dlist *headR = NULL;
    dlist *tailR = NULL;

    //Perform multiplication
    mulOperation(headOP1,
                 tailOP1,
                 headOP2,
                 tailOP2,
                 &headR,
                 &tailR);

    //Remove leading zeros from result
    strip_leading_zeros(&headR, &tailR);

    printf("The Product of 2 Operands is : ");

    //Print negative sign only if result is non-zero
    if (resultNegative && !is_zero(headR))
    {
        printf("-");
    }

    print_list(headR, tailR);
    printf("\n");

    //Free allocated memory
    free_list(&headOP1);
    free_list(&headOP2);
    free_list(&headR);
}