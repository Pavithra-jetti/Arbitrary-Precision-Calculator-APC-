#include "div.h"

/* Compare two numbers represented as doubly linked lists.
   Returns:
        1  -> head1 > head2
        0  -> head1 == head2
       -1  -> head1 < head2
*/
int compare(dlist *head1, dlist *head2)
{
    int len1 = 0, len2 = 0;
    dlist *temp;

    //Calculate length of first number
    temp = head1;
    while (temp != NULL)
    {
        len1++;
        temp = temp->next;
    }

    //Calculate length of second number
    temp = head2;
    while (temp != NULL)
    {
        len2++;
        temp = temp->next;
    }

    //Longer number is always greater
    if (len1 > len2)
        return 1;

    if (len1 < len2)
        return -1;

    //If lengths are equal, compare digit by digit
    while (head1 != NULL && head2 != NULL)
    {
        if (head1->data > head2->data)
            return 1;

        if (head1->data < head2->data)
            return -1;

        head1 = head1->next;
        head2 = head2->next;
    }

    return 0;
}

/* Move one digit from Dividend to Current number.
   This simulates bringing down one digit in long division.
*/
void append_digit(dlist **head1,dlist **tail1,dlist **head3,dlist **tail3)
{
    if (*head1 == NULL)
    {
        return;
    }

    //Append current digit to temporary dividend
    insert_last(head3, tail3, (*head1)->data);

    dlist *temp = *head1;

    //Remove that digit from original dividend
    *head1 = (*head1)->next;

    if (*head1 != NULL)
    {
        (*head1)->prev = NULL;
    }
    else
    {
        *tail1 = NULL;
    }

    free(temp);
}

/* Remove unnecessary leading zeros.
   Example:
        000123 -> 123
        0000   -> 0
*/
void remove_leading_zeros(dlist **head, dlist **tail)
{
    while (*head != NULL &&
           (*head)->data == 0 &&
           (*head)->next != NULL)
    {
        dlist *temp = *head;

        *head = (*head)->next;
        (*head)->prev = NULL;

        free(temp);
    }

    //Update tail pointer
    *tail = *head;

    if (*tail != NULL)
    {
        while ((*tail)->next != NULL)
        {
            *tail = (*tail)->next;
        }
    }
}

/* Subtract two linked-list numbers.
   Assumption:
        Number1 >= Number2
*/
void subtract_lists(dlist *tail1,dlist *tail2,dlist **headR,dlist **tailR)
{
    int borrow = 0;

    *headR = NULL;
    *tailR = NULL;

    //Start subtraction from Least Significant Digit
    while (tail1 != NULL || tail2 != NULL)
    {
        int n1 = 0;
        int n2 = 0;

        if (tail1 != NULL)
        {
            n1 = tail1->data;
            tail1 = tail1->prev;
        }

        if (tail2 != NULL)
        {
            n2 = tail2->data;
            tail2 = tail2->prev;
        }

        n1 = n1 - borrow;

        //Borrow if current digit is smaller
        if (n1 < n2)
        {
            n1 += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        insert_first(headR, tailR, n1 - n2);
    }

    //Remove leading zeros from result
    remove_leading_zeros(headR, tailR);
}

/* Perform Long Division.

   Algorithm:
   ----------
   1. Bring down one digit from dividend.
   2. Compare with divisor.
   3. Repeatedly subtract divisor until current number becomes smaller.
   4. Count number of subtractions.
   5. Count becomes one quotient digit.
   6. Repeat until dividend becomes empty.
*/
void divOperation(dlist **headDividend,dlist **tailDividend,
                  dlist *headDivisor,dlist *tailDivisor,
                  dlist **headQuotient,dlist **tailQuotient,
                  int negative)
{
    //Division by zero check
    if (is_zero(headDivisor))
    {
        printf("[ERROR] Division by zero is not allowed.\n");
        return;
    }

    //0 divided by anything
    if(is_zero(*headDividend))
    {
        printf("\nQuotient : 0\n");
        printf("Remainder : 0\n");
        return;
    }

    dlist *headCurrent = NULL;
    dlist *tailCurrent = NULL;

    //Continue until all digits are processed
    while (*headDividend != NULL)
    {
        //Bring down one digit
        append_digit(headDividend, tailDividend,
                     &headCurrent, &tailCurrent);

        remove_leading_zeros(&headCurrent, &tailCurrent);

        int count = 0;

        //Perform repeated subtraction
        while (compare(headCurrent, headDivisor) >= 0)
        {
            dlist *headTemp = NULL;
            dlist *tailTemp = NULL;

            subtract_lists(tailCurrent,tailDivisor,
                           &headTemp,&tailTemp);

            free_list(&headCurrent);

            headCurrent = headTemp;
            tailCurrent = tailTemp;

            count++;
        }

        //Store quotient digit
        insert_last(headQuotient, tailQuotient, count);
    }

    remove_leading_zeros(headQuotient, tailQuotient);

    //Handle quotient = 0
    if(*headQuotient == NULL)
    {
        insert_last(headQuotient, tailQuotient, 0);
    }

    printf("\nQuotient : ");

    //Print negative sign only if quotient is non-zero
    if(negative && !is_zero(*headQuotient))
    {
        printf("-");
    }

    print_list(*headQuotient, *tailQuotient);

    printf("\nRemainder : ");
    print_list(headCurrent, tailCurrent);

    //Free temporary lists
    free_list(&headCurrent);
    free_list(headQuotient);
}

/* Driver function for Division

   Responsibilities:
   -----------------
   1. Extract signs.
   2. Build linked lists.
   3. Print operands.
   4. Call division algorithm.
   5. Free allocated memory.
*/
void div_op(char *op1, char *op2)
{
    int sign1, sign2;

    //Remove '+' or '-' and store sign
    get_sign(&op1, &sign1);
    get_sign(&op2, &sign2);

    //Quotient is negative only if signs differ
    int negative = (sign1 != sign2);

    dlist *headDividend = NULL;
    dlist *tailDividend = NULL;

    dlist *headDivisor = NULL;
    dlist *tailDivisor = NULL;

    dlist *headQuotient = NULL;
    dlist *tailQuotient = NULL;

    //Convert first operand into linked list
    for (int i = 0; op1[i] != '\0'; i++)
    {
        insert_last(&headDividend, &tailDividend, op1[i] - '0');
    }

    //Convert second operand into linked list
    for (int i = 0; op2[i] != '\0'; i++)
    {
        insert_last(&headDivisor, &tailDivisor, op2[i] - '0');
    }

    printf("Dividend : ");
    if(sign1 == -1)
        printf("-");
    print_list(headDividend, tailDividend);

    printf("\nDivisor  : ");
    if(sign2 == -1)
        printf("-");
    print_list(headDivisor, tailDivisor);

    //Perform division
    divOperation(&headDividend,&tailDividend,
                 headDivisor,tailDivisor,
                 &headQuotient,&tailQuotient,
                 negative);

    //Free allocated memory
    free_list(&headDivisor);
    free_list(&headQuotient);
}