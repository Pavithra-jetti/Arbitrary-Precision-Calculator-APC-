#include "add.h"
#include "sub.h"

/* Driver function for Addition

   Responsibilities:
   -----------------
   1. Extract signs from operands.
   2. Convert operands into doubly linked lists.
   3. Print operands.
   4. Decide whether to perform addition or subtraction
      depending on operand signs.
   5. Free allocated memory.
*/
void add_op(char *op1, char *op2)
{
    int sign1, sign2;

    //Remove '+' or '-' and store operand signs
    get_sign(&op1, &sign1);
    get_sign(&op2, &sign2);

    dlist *headOP1 = NULL;
    dlist *tailOP1 = NULL;

    dlist *headOP2 = NULL;
    dlist *tailOP2 = NULL;

    //Convert Operand-1 into linked list
    for(int i = 0; op1[i] != '\0'; i++)
    {
        insert_last(&headOP1, &tailOP1, op1[i] - '0');
    }

    //Convert Operand-2 into linked list
    for(int i = 0; op2[i] != '\0'; i++)
    {
        insert_last(&headOP2, &tailOP2, op2[i] - '0');
    }

    printf("The operand1 is : ");
    if(sign1 == -1)
        printf("-");
    print_list(headOP1, tailOP1);

    printf("\nThe operand2 is : ");
    if(sign2 == -1)
        printf("-");
    print_list(headOP2, tailOP2);
    printf("\n");

    /* Sign combinations

       +A + +B = Addition
       -A + -B = -(A+B)
       +A + -B = A-B
       -A + +B = B-A
    */

    if(sign1 == 1 && sign2 == 1)
    {
        addOperation(headOP1, tailOP1,
                     headOP2, tailOP2,
                     0);
    }
    else if(sign1 == -1 && sign2 == -1)
    {
        addOperation(headOP1, tailOP1,
                     headOP2, tailOP2,
                     1);
    }
    else if(sign1 == 1 && sign2 == -1)
    {
        subtractOperation(headOP1, tailOP1,
                          headOP2, tailOP2,
                          0);
    }
    else
    {
        subtractOperation(headOP2, tailOP2,
                          headOP1, tailOP1,
                          0);
    }

    //Release allocated memory
    free_list(&headOP1);
    free_list(&headOP2);
}

/* Perform Addition

   Algorithm:
   ----------
   1. Start from Least Significant Digit (tail).
   2. Add corresponding digits and carry.
   3. Store result digit at the beginning of result list.
   4. Continue until both numbers are exhausted.
   5. Insert final carry if present.
*/
void addOperation(dlist *headOP1,
                  dlist *tailOP1,
                  dlist *headOP2,
                  dlist *tailOP2,
                  int negative)
{
    dlist *headR = NULL;
    dlist *tailR = NULL;

    int carry = 0;

    //Traverse from LSD to MSD
    while(tailOP1 != NULL || tailOP2 != NULL)
    {
        int num1 = 0;
        int num2 = 0;

        //Fetch digit from Operand-1
        if(tailOP1 != NULL)
        {
            num1 = tailOP1->data;
            tailOP1 = tailOP1->prev;
        }

        //Fetch digit from Operand-2
        if(tailOP2 != NULL)
        {
            num2 = tailOP2->data;
            tailOP2 = tailOP2->prev;
        }

        //Calculate sum including carry
        int sum = num1 + num2 + carry;

        //Update carry for next iteration
        carry = sum / 10;

        //Store current result digit
        insert_first(&headR, &tailR, sum % 10);
    }

    //Insert remaining carry
    if(carry)
    {
        insert_first(&headR, &tailR, carry);
    }

    printf("The Sum of 2 Operands is : ");

    //Print '-' only if result is negative
    if(negative)
        printf("-");

    print_list(headR, tailR);
    printf("\n");

    //Free result list
    free_list(&headR);
}