/* 
Name: J pavithra
Date: 08/08/2026
Description: An Arbitrary Precision Calculator implemented in C using Doubly Linked Lists to perform arithmetic operations on integers of unlimited size.*/


#include "add.h"
#include "sub.h"
#include "apc.h"
#include "mul.h"
#include "div.h"

int validate_Op(char *str);

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("[ERROR] Invalid number of arguments.\n");
        printf("Usage: ./a.out <Operand1> <Operator> <Operand2>\n");
        printf("Example: ./a.out 12345 + 67890\n");
        return 1;
    }

    if (validate_Op(argv[2]) != 1)
    {
        printf("[ERROR] Invalid operator.\n");
        printf("Supported operators: +  -  *  /\n");
        return 1;
    }

    char *Op1 = argv[1];

    //Reject input containing only '+' or '-' 
    if ((Op1[0] == '+' || Op1[0] == '-') && Op1[1] == '\0')
    {
        printf("[ERROR] Operand 1 is invalid.\n");
        return 1;
    }

    //Validate Operand1. A leading '+' or '-' is allowed. Remaining characters must be digits. 
    for (int i = 0; Op1[i] != '\0'; i++)
    {
        if(i==0 && (Op1[i]=='-' || Op1[i]=='+'))
        {
            continue;
        }
        if (!isdigit(Op1[i]))
        {
            printf("[ERROR] Operand 1 is invalid.\n");
            printf("Only numeric digits (0-9) are allowed.\n");
            return 1;
        }
    }
    char *Op2 = argv[3];

    //Validate Operand2. A leading '+' or '-' is allowed.Remaining characters must be digits.
    for (int i = 0; Op2[i] != '\0'; i++)
    {
        if(i==0 && (Op2[i]=='-' || Op2[i]=='+'))
        {
            continue;
        }
        
        if (!isdigit(Op2[i]))
        {
            printf("[ERROR] Operand 2 is invalid.\n");
            printf("Only numeric digits (0-9) are allowed.\n");
            return 0;
        }
    }
    printf("[INFO] Input validation successful.\n");

    //Call the corresponding arithmetic operation 
    if (strcmp(argv[2], "+") == 0)
    {
        add_op(Op1, Op2);
    }
    else if (strcmp(argv[2], "-") == 0)
    {
        sub_op(Op1, Op2);
    }
    else if (strcmp(argv[2], "x") == 0)
    {
        mul_op(Op1, Op2);
    }
    else if (strcmp(argv[2], "/") == 0)
    {
        div_op(Op1, Op2);
    }
    printf("\n");
    return 0;

}


/*
 Function : validate_Op()
 Purpose  : Checks whether the given operator is supported.
 Input    : Operator string.
 Returns  : 1 -> Valid operator
            0 -> Invalid operator  */
        
int validate_Op(char *str)
{
    char *op[] = {"+", "-", "x", "/"};
    for (int i = 0; i < 4; i++)
    {
        if (strcmp(str, op[i]) == 0)
        {
            return 1;
        }
    }
    return 0;
}